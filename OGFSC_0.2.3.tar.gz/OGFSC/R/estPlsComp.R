estPlsComp <- function(X, Y, maxNC, NCV, prep)
{
  # The function to estimate the critical number of PLS components by CV
  # Input: X - m by n data matrix with m cells and n genes 
  #        Y - m by k dummy matrix with m cells and k cell categories
  #        maxNC - the maximum value of the number of each PLS model
  #        NCV   - J-fold of cross validation
  #        prep  - candidate scaling methods, 'mc', 'pa' or 'uv'
  # Output: estNC - the estimated critical number of PLS components
  #         Q2max - the Q2 value corresponding to the critical number of PLS components
  # Xin Zou & Jie Hao
  # 2019, SJTU, China
  
  
  # add random interference
  X = X+0.000001*matrix(runif(dim(X)[1]*dim(X)[2]), dim(X)[1])
  # PLS model construction
  block_num = floor(dim(X)[1]/NCV)
  Q2_ori_1 = 0
  Q2_ori_2 = 0
  nsx = dim(X)[1]
  nvx = dim(X)[2]
  for (nc in 1:maxNC)
  {
    Q2Yhatcum = rep(0,NCV)
    for (cv in 1:NCV)
    {
      # cross validation
      idx_test = NCV*((1:block_num)-1)+cv
      idx_tr = 1:nsx
      idx_tr = idx_tr[-idx_test]
      X_test = X[idx_test,]
      Y_test = Y[idx_test,]
      X_tr = X[idx_tr,]
      Y_tr = Y[idx_tr,]
      
      nsx_tr=dim(X_tr)[1]
      nvx_tr=dim(X_tr)[2]
      nsy_tr=dim(Y_tr)[1]
      nvy_tr=dim(Y_tr)[2]
      nsx_test=dim(X_test)[1]
      nvx_test=dim(X_test)[2]
      nsy_test=dim(Y_test)[1]
      nvy_test=dim(Y_test)[2]
      # scaling
      if (prep == 'no')
      {
        #model$preprocessing='no'
      } else if (prep == 'mc')
      {
        # disp('Meancentering')
        # model$preprocessing = 'mc'
        X_tr=X_tr- t(matrix(rep(colMeans(X_tr),nsx_tr),dim(X_tr)[2]))
        Y_tr=Y_tr- t(matrix(rep(colMeans(Y_tr),nsy_tr),dim(Y_tr)[2]))
        X_test=X_test-t(matrix(rep(colMeans(X_test),nsx_test),dim(X_test)[2]))
        Y_test=Y_test-t(matrix(rep(colMeans(Y_test),nsy_test),dim(Y_test)[2]))
      } else if (prep == 'uv')
      {
        # disp('Univariance scaling')
        #model$preprocessing='uv';
        X_tr=X_tr- t(matrix(rep(clMeans(X_tr),nsx_tr),dim(X_tr)[2]))
        Y_tr=Y_tr- t(matrix(rep(colMeans(Y_tr),nsy_tr),dim(Y_tr)[2]))
        X_tr=X_tr/t(matrix(rep(apply(X_tr,2,sd),nsx_tr),dim(X_tr)[2]))
        Y_tr=Y_tr/t(matrix(rep(apply(Y_tr,2,sd),nsy_tr),dim(Y_tr)[2]))
        
        
        X_test=X_test-t(matrix(rep(colMeans(X_test),nsx_test),dim(X_test)[2]))
        Y_test=Y_test-t(matrix(rep(colMeans(Y_test),nsy_test),dim(Y_test)[2]))
        
        X_test=X_test/t(matrix(rep(apply(X_test,2,sd),nsx_test),dim(X_test)[2]))
        Y_test=Y_test/t(matrix(rep(apply(Y_test,2,sd),nsy_test),dim(Y_test)[2]))
        
      } else if (prep == 'pa') 
        {
        #model$preprocessing='pa'
        X_tr=X_tr- t(matrix(rep(colMeans(X_tr),nsx_tr),dim(X_tr)[2]))
        Y_tr=Y_tr- t(matrix(rep(colMeans(Y_tr),nsy_tr),dim(Y_tr)[2]))
        
        X_tr=X_tr/t(matrix(rep(sqrt(apply(X_tr,2,sd)),nsx_tr),dim(X_tr)[2]))
        Y_tr=Y_tr/t(matrix(rep(sqrt(apply(Y_tr,2,sd)),nsy_tr),dim(Y_tr)[2]))
        
        X_test=X_test-t(matrix(rep(colMeans(X_test),nsx_test),dim(X_test)[2]))
        Y_test=Y_test-t(matrix(rep(colMeans(Y_test),nsy_test),dim(Y_test)[2]))
        
        X_test=X_test/t(matrix(rep(sqrt(apply(X_test,2,sd)),nsx_test),dim(X_test)[2]))
        Y_test=Y_test/t(matrix(rep(sqrt(apply(Y_test,2,sd)),nsy_test),dim(Y_test)[2]))
        
      } else 
        {
        cat("Unknown Preprocessing\n")
        #model = NULL
        ePLS <- list(estNC = NULL, Q2max = NULL)
        return (ePLS)
      }
      
      
      # model construction
      PLS1 = plsr(Y_tr ~ X_tr,ncomp = nc,model = TRUE)
      BETA = as.matrix(coef(PLS1, ncomp = nc,intercept = TRUE))
      BETA = matrix(BETA,dim(BETA)/2,2)
      # predicting on the model
      PredY = cbind(rep(1, dim(X_test)[1]),X_test)%*%BETA
      # calculating Q2
      SSY=sum(Y_test^2)
      Q2Yhatcum[cv] = 1-sum((PredY-Y_test)*(PredY-Y_test))/SSY
    }
    Q2 = mean(Q2Yhatcum[which(!is.na(Q2Yhatcum))])
    # check if the current Q2 value is the maximum point
    if (Q2_ori_2>Q2 && Q2_ori_2>Q2_ori_1)
    {
      estNC = nc - 2 # this is the critical number of PLS components
      break
    } else 
      {
      Q2_ori_2 = Q2_ori_1;
      Q2_ori_1 = Q2;
      #         estNC = nc;
    }
  }
  
  Q2max = Q2_ori_2 # this is the Q2 corresponding to the critical number of PLS components
  
  ePLS <- list(estNC = estNC, Q2max = Q2max)
  return (ePLS)
}
