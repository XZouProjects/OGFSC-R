TW_trace_ratio_threshold <- function(p,n,beta=1,alpha)
{
  # Code by Jie Hao and Xin Zou
  # 2018, SJTU
  #function [t s] = TW_trace_ratio_threshold(p,n,beta,alpha)
  # Let L_j be the eigenvalues of the sample covariance matrix of multivariate
  # Gaussian obserations with n samples in p dimensions, 
  #
  # INPUT:  p = dimension, n = number of samples, 
  #         beta = 1/2 real/complex valued data, 
  #         alpha = desired false alarm / right tail probability
  #
  # OUTPUT: t = An approximate value such that Pr[ L_1/(1/p sum(L_j) )> t ] ~  alpha
  #         s = Pr[ (L_1/(1/p sum(L_j) - mu)/sigma > s] ~ alpha
  #
  #
  # Threshold s is found by interpolation of precomumputed values of the
  # Tracy-Widom distribution, and its second derivative. 
  # These were generated using code by Prof. Folkmar Bornemann, based on his paper
  # On the Numerical Evaluation of Distributions in Random Matrix Theory, 2010. 
  #
  # http://www.wisdom.weizmann.ac.il/~nadler/Wishart_Ratio_Trace/TW_ratio.html
  
  if (beta==1)
  {
    load(file = "TW_beta1.Rdata")
  } else
  {
    load(file = "TW_beta2.Rdata")
  }
  
  mu_np<-NULL
  sigma_np<-NULL
  # mu_np and sigma_np - centering and scaling

  KN = KN_mu_sigma(n,p,beta) 
  mu_np = KN$mu_np / n  
  sigma_np = KN$sigma_np / n  
  
  # Eq. 1.7 in paper [1]
  U_cdf_complementary = 1-TW_s + 1/beta/n/p *(mu_np/sigma_np)^2* TW_s_tag_tag  
  
  # next find index where probability is close to alpha
  idx = which.min(abs(U_cdf_complementary-alpha))  
  
  t = mu_np + sigma_np * x[idx]  
  s = x[idx]  
  TW <- list(t = t, s = s, mu_np = mu_np, sigma_np =  sigma_np)
  return(TW)
}

