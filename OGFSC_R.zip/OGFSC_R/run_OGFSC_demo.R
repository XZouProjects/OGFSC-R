warnDef<-options("warn")$warn
warnRead<-options(warn = -1)
setwd("G:/algorithms/OGFSC/OGFSC_R")
source('OGFSC.R')
source('TW_trace_ratio_threshold.R')
source('KN_mu_sigma.R')
#install.packages("tsne")
#install.packages("RColorBrewer")


## load data and pre-processing
raw = read.table('GSE59739_DataTable_R.csv',sep = ",")
data = raw[3:dim(raw)[1], 2:dim(raw)[2]] 
pickingSession = raw[1, 2:dim(raw)[2]] 
cell_IDs = raw[2, 2:dim(raw)[2]] 
geneList = matrix(raw[3:dim(raw)[1], 1])
cell_type_unique = c('NF1','NF2','NF3', 'NF4','NF5','NP1', 'NP2', 'NP3', 'PEP1', 'PEP2', 'TH')
cell_types = rep(0, dim(cell_IDs)[2]) 
for (i in 1:length(cell_type_unique))
{
idx1 = which(cell_IDs == cell_type_unique[i])  
cell_types[idx1] = i 
}
idx = which(cell_types!=0) 
cell_types = cell_types[idx]
data = (data[,idx])
data = as.matrix(data)
data = apply(data,2,as.numeric)

# # removing batch effect
pickingSession = pickingSession[idx]
pickingSession_uni = sort(unique(t(pickingSession)))
pickingSe = rep(0, dim(pickingSession)[2]) 
for (i in 1:length(pickingSession_uni))
{
idx = which(pickingSession == pickingSession_uni[i])
pickingSe[idx] = i 
}

sigma2 = apply(data,1,var) 
## log transform
log2Data = log2(data +1) 
## gene filtering by OGFSC and save result

OGF = OGFSC(log2Data, plot_option = 1) 
OGFSC_idx = OGF$OGFSC_idx 
idx_output = OGF$idx_output
cv2_threshold = OGF$cv2_threshold 

dataBuffer_OGFSC = log2Data[OGFSC_idx,] 
temp = data[OGFSC_idx,] 
temp = cbind(geneList[OGFSC_idx], temp) 
write.table(temp, file = "OGFSCFilteredData.csv", quote = F, sep = ",",row.names = F,col.names = F) 
## scatter plots
X = t(dataBuffer_OGFSC) 
PCA = prcomp(X) 
SCORE = PCA$x
library("tsne")
ydata = tsne(X,initial_config = (SCORE[,1:5]),k =5, max_iter =200,whiten = F,epoch=300) 

library("RColorBrewer")
cols<-brewer.pal(n=11,name="Set3")
x11()
for (i in 1:max(cell_types))
{
idx = which(cell_types==i) 
  if (i ==1)
  {
    plot(ydata[,1], ydata[,2], type = "n", xlab = expression(tSNE[1]), 
         ylab= expression(tSNE[2]),
         main = "OGFSC",cex.lab=1.2,cex.axis=1.2)
  }
  points(ydata[idx,1], ydata[idx,2], pch = 16, col = cols[i])
}
legend("topright", legend = cell_type_unique, col = cols, pch = 16) 

##
N1 = round(0.06*dim(data)[2]) 
N2 = round(0.94*dim(data)[2]) 
idx1 = which(rowSums(data>2)<N1) 
idx2 = which(rowSums(data>0)>N2) 
Idx_ref = sort(unique(c(idx1, idx2))) 

# # scatter plot
X = t(log2Data[Idx_ref,])
PCA = prcomp(X) 
SCORE = PCA$x
ydata = tsne(X,initial_config = (SCORE[,1:5]),k =5, max_iter =200,whiten = F,epoch=300) 

x11()
for (i in 1:max(cell_types))
{
  idx = which(cell_types==i) 
  if (i ==1)
  {
    plot(ydata[,1], ydata[,2], type = "n", xlab = expression(tSNE[1]), 
         ylab= expression(tSNE[2]),
         cex.lab=1.2,cex.axis=1.2)
  }
  points(ydata[idx,1], ydata[idx,2], pch = 16, col = cols[i])
}
legend("topright", legend = cell_type_unique, col = cols, pch = 16)


warnRead<-options(warn = warnDef)

